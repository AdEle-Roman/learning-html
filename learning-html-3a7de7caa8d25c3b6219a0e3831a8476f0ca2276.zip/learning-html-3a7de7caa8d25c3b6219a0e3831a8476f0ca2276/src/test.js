const foo = 1;
console.log(foo);
